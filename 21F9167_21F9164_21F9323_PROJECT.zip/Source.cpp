//21F-9323, Huzaifa M.Arshad
//21F-9167, Saad Ashraf
//21F-9164, Ali Akbar


#include<iostream>
#include<fstream>
#include<conio.h>
#include<cstring>
#include<string>
#include<Windows.h>
#include "Project.h"
using namespace std;

int main() {
    shopping a;
    a.menu();
}
