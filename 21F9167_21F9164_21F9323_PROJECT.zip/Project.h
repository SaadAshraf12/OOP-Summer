#pragma once
#include<iostream>
#include<fstream>
#include<conio.h>
#include<cstring>
#include<string>
#include<Windows.h>
using namespace std;

class variables {
protected:
    int pcode;
    float price;
    float dis;
    string pname;
    fstream data, data1;
    int pkey;
    int token = 0;
    int c;
    float p, d;
    string n, name, username, email, password, date, gender, blood, phone_no, address, cid, id, usn, psd;
    bool b = false;
public:
    void add_shopkeeper();
    void shopkeeper_menu();
};

class shopping : public variables {
private:
    char SAName[20];
    char SAPass[20];
    int ch, i = 0, gen_captcha = 0, Input_captcha = 0;
public:
    bool Admin_login();
    void menu();
    void administrator();
    void add();
    void edit();
    void rem();
    void list();
    void shopkeeper_menu1();
    void update_data();
};
