#include<iostream>
using namespace std;
int isPalindrome(char str[], int first, int last) {
	if (first < last + 1) {
		first++;
		last--;
		return isPalindrome(str, first, last);
	}

	if (first == last) {
		cout << "is palindrome";
		return 1;
	}
	if (str[first] != str[last]) {
		cout << "is palindrome" << endl;
		return 0;
	}
	else {
		cout << "is  not Palindrome" << endl;
		return true;
	}
	return 1;
}
int main() {
	char Str[] = "sad";
	int result;
	int length = strlen(Str);
	if (length == 0) {
		result = 1;
	}
	cout << "dad ";
	isPalindrome("dad", 13, 5);
	system("pause");
}
