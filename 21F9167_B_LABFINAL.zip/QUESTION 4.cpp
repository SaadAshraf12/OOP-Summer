#include<iostream>
#include<string>
#include<cstring>
#include"Header.h"

using namespace std;

int main() {
	PersonBio p;
	p.setName("saad");
	p.setProfession_name("CEO");
	p.setAge(18);
	p.print();
	p.~PersonBio();

	Address a;
	cout << endl;
	a.sethousenumber(123);
	a.setstreetnumber(456);
	a.setapartmentnumber(789);
	a.setpostalcode(92);
	a.setcityname("Lahore");
	a.setstatename("Punjab");
	a.print();
	a.inputfunction();
	a.print();
	a.~Address();


	Address a1;
	a1.inputfunction();
	a1.print();
	a.~Address();


	system("pause");


}
