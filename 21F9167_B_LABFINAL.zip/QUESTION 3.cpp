#include<iostream>
using namespace std;

void input(int **p, int row, int col) {

}

void display(int **p, int row, int col) {

}

int** multiply(int **p, int row, int col, int **q, int row2, int col2) {

}

int main() {
	int rows1, coloumns1;
	int rows2, coloumns2;
	
	cout << "enter number of rows of matrix A : ";
	cin >> rows1;
	cout << "enter number of coloumns of matrix A : ";
	cin >> coloumns1;

	cout << "enter number of rows of matrix B : ";
	cin >> rows2;
	cout << "enter number of coloumns of matrix B : ";
	cin >> coloumns2;

	while (coloumns1 != rows2) {
		cout << "error columns of matrix A must be equal to rows of matrix B";
		cin >> coloumns1;
		cin >> rows2;
	}


}