#pragma once
#include<iostream>
#include<string>
#include<cstring>
using namespace std;


class Person {
private:
	string name;
	int age;
	char gender;
public:
	Person() {
		name = "";
		age = 0;
		gender = 'a';
	}
	void setName(string nname) {
		name = nname;
	}
	void setAge(int aage) {
		age = aage;
	}
	void setGender(char ggender) {
		gender = ggender;
	}
	string getName() {
		return name;
	}
	int getAge() {
		return age;
	}
	char gerGender() {
		return gender;
	}
	void print() {
		cout << "Name: " << name << endl;
		cout << "Age : " << age << endl;
		cout << "Gender : " << gender << endl;
	}

};



class Faculty : public Person {
private:
	string course;
	int fid;
public:

	void setCourse(string ccourse) {
		course = ccourse;
	}
	void setFid(int ffid) {
		fid = ffid;
	}
	string getCourse() {
		return course;
	}
	int getFid() {
		return fid;
	}
	void print() {
		cout << "Fid : " << fid << endl;
		cout << "Course : " << course << endl;
	}

};


class Student {
private:
	int sid;
	string batch;
public:
	void setBatch(string bbatch) {
		batch = bbatch;
	}
	void setSid(int ssid) {
		sid = ssid;
	}
	string getBatch() {
		return batch;
	}
	int getSid() {
		return sid;
	}
	void print() {
		cout << "Sid : " << sid << endl;
		cout << "Batch : " << batch << endl;
	}


};


class Admin :public Faculty, public Student {
private:
	string department;
public:
	void setDepartment(string ddepartment) {
		department = ddepartment;
	}
	string getDepartment() {
		return department;
	}
	void print() {
		cout << "Department : " << department << endl;
	}
};

