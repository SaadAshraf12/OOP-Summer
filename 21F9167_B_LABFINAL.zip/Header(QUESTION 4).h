#pragma once
#include<iostream>
#include<string>
#include<cstring>
using namespace std;

class PersonBio {
private:
	string name;
	string profession_name;
	int age;
public:
	PersonBio() {
		name = "";
		profession_name = "";
		age = 0;
	}
	void setName(string nname) {
		name = nname;
	}
	void setProfession_name(string pprofession_name) {
		profession_name = pprofession_name;
	}
	void setAge(int aage) {
		age = aage;
	}
	string getName() {
		return name;
	}
	string getProfession_name() {
		return profession_name;
	}
	int getAge() {
		return age;
	}
	void print() {
		cout << "Name : " << name << endl;
		cout << "Profession Name : " << profession_name << endl;
		cout << "Age : " << age << endl;
	}
	~PersonBio() {
		cout << "i am destructor of personbio class and objects are finished" << endl;
	}
};


class Address {
private:
	int housenumber, streetnumber, apartmentnumber, postalcode;
	string cityname, statename;
public:
	Address() {
		housenumber = 0;
		streetnumber = 0;
		apartmentnumber = 0;
		postalcode = 0;
		cityname = "";
		statename = "";
		cout << "I am Default Constructor of Address class";
	}

	Address(int a, int b, int c, int d, string e, string f) {
		housenumber = a;
		streetnumber = b;
		apartmentnumber = c;
		postalcode = d;
		cityname = e;
		statename = f;
		cout << "I am Parameterized Constructor";
	}
	void sethousenumber(int g) {
		housenumber = g;
	}
	void setstreetnumber(int h) {
		streetnumber = h;
	}
	void setapartmentnumber(int i) {
		apartmentnumber = i;
	}
	void setpostalcode(int j) {
		postalcode = j;
	}
	void setcityname(string k) {
		cityname = k;
	}
	void setstatename(string l) {
		statename = l;
	}

	int gethousenumber() {
		return housenumber;
	}
	int getstreetnumber() {
		return streetnumber;
	}
	int getapartmentnumber() {
		return apartmentnumber;
	}
	int getpostalcode() {
		return postalcode;
	}
	string getcityname() {
		return cityname;
	}
	string getstatename() {
		return statename;
	}

	void inputfunction() {
		cout << endl;
		cout << "enter house number: ";
		cin >> housenumber;
		cout << "enter streetnumber: ";
		cin >> streetnumber;
		cout << "enter apartmentnumber: ";
		cin >> apartmentnumber;
		cout << "enter postalcode: ";
		cin >> postalcode;
		cout << "enter cityname: ";
		cin >> cityname;
		cout << "enter statename: ";
		cin >> statename;
	}

	void print() {
		cout << "house number : " << housenumber << "  street number : " << streetnumber << "   apartment number : " << apartmentnumber << endl;
		cout << "city name : " << cityname << "   state name: " << statename << "   postal code: " << postalcode << endl;
	}


	~Address() {
		cout << "i am destructor of Address class and objects are finished" << endl;
	}
};