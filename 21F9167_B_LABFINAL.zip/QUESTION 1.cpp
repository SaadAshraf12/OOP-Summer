#include<iostream>
#include<string>
#include<cstring>
#include"Header.h"
using namespace std;

int main() {
	Person p;
	p.setName("saad");
	p.setAge(10);
	p.setGender('M');
	p.print();


	Faculty f;
	f.setFid(100);
	f.setCourse("OOP");
	f.print();


	Student s;
	s.setBatch("21st");
	s.setSid(123);
	s.print();


	Admin a;
	a.setDepartment("CS");
	a.print();

	system("pause");
}

